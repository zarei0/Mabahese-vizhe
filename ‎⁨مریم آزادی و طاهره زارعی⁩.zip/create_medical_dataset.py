
import pandas as pd
import random

# تنظیمات پایه
num_samples = 100
eye_colors = ['قهوه\u200cای', 'آبی', 'سبز', 'مشکی', 'کهربایی']
male_names = ['آرش', 'پیمان', 'جواد', 'سامان', 'کیوان', 'نیما', 'رضا', 'شایان', 'فرهاد', 'امیر']
female_names = ['بهاره', 'نگار', 'سحر', 'لیلا', 'مریم', 'نازنین', 'الهام', 'شبنم', 'رها', 'سمانه']
last_names = ['احمدی', 'باقری', 'پوری', 'کریمی', 'قاسمی', 'رستمی', 'میرزایی', 'نعمتی', 'صادقی', 'زارعی']

data = []
for i in range(1, num_samples + 1):
    gender = random.randint(0, 1)
    first_name = random.choice(male_names) if gender == 1 else random.choice(female_names)
    last_name = random.choice(last_names)
    eye_color = random.choice(eye_colors)
    height = random.randint(150, 200)
    weight = random.randint(50, 100)
    blood_pressure = random.randint(90, 140)
    blood_sugar = random.randint(70, 120)
    cholesterol = random.randint(150, 250)
    heart_rate = random.randint(60, 100)
    temperature = round(random.uniform(36.5, 37.5), 1)
    vitamin_d = random.randint(10, 40)
    hb = round(random.uniform(12.0, 17.0), 1)
    a1c = round(random.uniform(4.5, 6.5), 1)
    iron = random.randint(50, 150)
    fat = random.randint(140, 250)
    bmi = round(weight / ((height / 100) ** 2), 1)
    oxygen = random.randint(94, 100)
    age = random.randint(18, 80)
    
    row = [i, first_name, last_name, eye_color, gender, height, weight, blood_pressure, blood_sugar,
           cholesterol, heart_rate, temperature, vitamin_d, hb, a1c, iron, fat, bmi, oxygen, age]
    data.append(row)

columns = ['id', 'نام', 'نام خانوادگی', 'رنگ چشم', 'جنسیت',
           'قد (cm)', 'وزن (kg)', 'فشار خون', 'قند خون', 'کلسترول',
           'ضربان قلب', 'دما (°C)', 'ویتامین D', 'HB', 'A1C', 'آهن',
           'چربی خون', 'BMI', 'اکسیژن خون', 'سن']

df = pd.DataFrame(data, columns=columns)

# ذخیره به عنوان CSV
df.to_csv("medical_dataset_farsi.csv", index=False, encoding='utf-8-sig')

# ذخیره به عنوان Excel
df.to_excel("medical_dataset_farsi.xlsx", index=False, engine='openpyxl')
